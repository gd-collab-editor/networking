#include <level.hpp>

class GameObject;

#define ACTION(cls, enm) \
    class cls : public ObjectAction { \
     public: \
         void apply_server(GD::Level& lvl, GD::Block& b) override; \
         void apply_client(GameObject* b) override; \
         enum ActionType type = enm; \
    }

enum ActionType {
    DUMMY
};

class ObjectAction {
 public:
    virtual void apply_server(GD::Level& lvl, GD::Block& b) {};
    virtual void apply_client(GameObject* b) {};

    enum ActionType type;
};

// ACTIONS HERE

ACTION(DummyAction, DUMMY); // TEMPORARY