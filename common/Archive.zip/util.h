#pragma once

#include <algorithm>
#include <vector>

template <typename T>
inline void vec_remove_val(std::vector<T>& vec, T val) {
    vec.erase(std::remove(vec.begin(), vec.end(), val), vec.end());
}
